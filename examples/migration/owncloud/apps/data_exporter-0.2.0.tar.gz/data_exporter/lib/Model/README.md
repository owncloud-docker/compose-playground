Defines the format of the import/export. Docblocks are important since they
are used for serialization.